import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;


import javax.swing.JPanel;
import javax.swing.Timer;



public class Play extends JPanel implements KeyListener {
	protected int score = 0;
	protected int wval = 0;
	protected int ival = 0;
	protected int nval = 0;
	protected int gravity = 0;
	protected int endlevel = 3000;
	protected int xval = 300;
	protected int yval = 250;
	protected int ballx = 550;
	protected int bally = 10;
	protected int velx = 0;
	protected int vely = 5;
	protected int gametime = 0;
	protected int time = -1;
	protected int clock = 0; 
	protected int setter = 1;
	protected int counter = 0;
	public int fallhold = 0;
	protected int fall = 0;
	protected int bSi = 15;
	protected int bSp = 9;
	protected int pS = 15;
	protected int level= 1;
	protected String gameclock = "0";
	protected double angle = 90;
	protected int playcase = 0;
	protected int lives = 3;
	protected String livesleft = "3";
	protected String bonk = "bonk";
	protected int restart = 1;
	protected boolean start = false;
	//
	public void paintComponent(Graphics g){
		if(restart == 0){
			gameclock = "0";
			clock = 0;
			gametime = 0;
			endlevel += 1500;
			xval = 300;
			yval = 250;
			ballx = 550;
		    bally = 10;
		    restart = 1;
		    playcase = 0;
		}
		if(start == true){
			ival = 0;
			score = 0;
			wval = 0;
			nval = 0;
			 bSi = 15;
			 bSp = 9;
			 pS = 15;
			level = 1;
			lives = 3;
			gameclock = "0";
			clock = 0;
			gametime = 0;
			fall = 0;
			endlevel = 3000;
			xval = 300;
			yval = 250;
			ballx = 550;
		    bally = 10;
		    restart = 1;
		    playcase = 0;
		    start = false;
		}
		if (level == 2){
			bSi = 5;
			pS = 5;
			bSp = 9;
		}
		if(level == 3){
			bSi = 0;
			pS = -5;
			bSp = 9;
		}
		if(fallhold != 0){
			ival = 0;
			wval = 0;
			nval = 0;
			gravity = 0;
			fall+=1;
			lives -=1;
			ballx = 550;
			bally = 50;
			fallhold = 0;
			score -=10;
		}
		if(fall < 3 && level != 4){
		super.paintComponent(g);
		g.setColor(Color.white);
		g.drawString("Score", 520, 45);
		g.drawString(Integer.toString(score), 560, 45);
		g.setColor(Color.white);
		g.drawString("Level", 15, 50);
		g.drawString(Integer.toString(level), 45, 50);
		livesleft = Integer.toString(lives);
		g.drawString("Lives: ", 15, 20);
		g.drawString(livesleft, 50, 20);
		g.drawString(gameclock, 550, 20);
		g.setColor(Color.green);
		g.fillRect(xval, yval, 50 + pS, 10);
		g.setColor(Color.blue);
		g.fillOval(ballx, bally, 20+bSi, 20+bSi);
		}
		if(fall == 3){
			super.paintComponent(g);
			g.setColor(Color.white);
			livesleft = Integer.toString(lives);
			g.drawString(Integer.toString(score), 560, 45);
			g.drawString("Lives: ", 15, 20);
			g.drawString(livesleft, 50, 20);
			g.drawString("Game Over", 300, 150);
			
		}
		if(level == 4){
			super.paintComponent(g);
			g.setColor(Color.white);
			g.drawString("Score", 520, 45);
			g.drawString(Integer.toString(score), 560, 45);
			g.drawString("Winning #GOTY2015", 15, 50);
			
			livesleft = Integer.toString(lives);
			g.drawString("Lives: ", 15, 20);
			g.drawString(livesleft, 50, 20);;
			g.drawString("You're Winner!", 285, 150);
			
		}
	}
	
	protected Timer move;
	protected boolean go = false;
	public Play(){
		this.go = go;
		this.start = start;
		move = new Timer(10, new movement());
		addKeyListener(this);
		move.start();
	}
	public boolean getGo(){
		return go;
	}
	public boolean getStart(){
		return start;
	}
	public void setStart(boolean start){
		this.start = start;
	}
	public void setGo(boolean go){
		this.go = go;
	}
	//
	class movement implements ActionListener{
	
	public void actionPerformed(ActionEvent e) {
		if(go == true ){
		gravity += 1;
		counter +=1;
		if(counter/300 == 1){//cheatcode must be entered within 3 seconds
			ival = 0;
			wval = 0;
			nval = 0;
		}
		gametime+=1;
		if(gametime%100 == 0){
			clock +=1;
			gameclock = Integer.toString(clock);
		}
		if(level != 4){
		level();
		}
		switch (playcase){ ///these cases decide how the ball moves using the provided equations
		case 0: vely = 1; 
		velx =(int) ( 3 * (Math.cos(angle)));
		break;
		case 1: vely = (int) (-1 * ( bSp * (Math.sin(angle))*(time/100) - (4.9*(Math.pow((time/100),2)))));
		time =100;
		
		break;
		case 2: vely = (int) (-1 *(( bSp * (Math.sin(angle))*(time/100) - (4.9*(Math.pow((time/100),2))))));
		velx =(int) ( 3 * (Math.cos(angle)));
		time=100;
		
		break;
		case 3: vely = (int)(1*(( bSp * (Math.sin(angle))*(time/100) - (4.9*(Math.pow((time/100),2))))));
		velx =(int) (  -3 * (Math.cos(angle)));
		time =100;
		
		break;
		case 4: vely = (int) (1*(( bSp * (Math.sin(angle))*(time/100) - (4.9*(Math.pow((time/100),2))))));
		time =100;
		
		break;
		}
		if(gametime == endlevel){
			level += 1;
			restart = 0;
			gravity = 0;
		}
		if(playcase !=0){
		vely += gravity/25;
		}  
        bally += vely;// ball position is changed and affected by gravity
		ballx +=velx;
		repaint();
	}

	}
}
	@Override
	public void keyPressed(KeyEvent e) {//game controls and cheat code system. Controlable via arrow keys and wasd
		System.out.println("KetActivate");
		 if (e.getKeyCode() == KeyEvent.VK_RIGHT ) {
			 if(xval < 520){
	            xval +=6;
	            }
	    } else if (e.getKeyCode() == KeyEvent.VK_LEFT ) {
	    	if(xval > 0){
	    	xval -=6;
	    	}
	    	
	    } else if (e.getKeyCode() == KeyEvent.VK_UP ) {
	    	if(yval > 0){
	    		yval -=3;
	    	}
	    }
	    	
	    else if (e.getKeyCode() == KeyEvent.VK_DOWN ) {
	        if(yval < 290){
	        	yval +=3;
	        }
	    }
		 if (e.getKeyCode() == KeyEvent.VK_D ) {
			 if(xval < 520){
	            xval +=3;
	            }
	    } else if (e.getKeyCode() == KeyEvent.VK_A ) {
	    	if(xval > 0){
	    	xval -=3;
	    	}
	    	
	    } else if (e.getKeyCode() == KeyEvent.VK_W ) {
	    	if(yval > 0){
	    		yval -=3;
	    	}
	    }
	    	
	    else if (e.getKeyCode() == KeyEvent.VK_S ) {
	        if(yval < 290){
	        	yval +=3;
	        }
	    }
		
		if(e.getKeyCode() == KeyEvent.VK_W){
			wval = 1;
			counter = 0;
		} 
		if(e.getKeyCode() == KeyEvent.VK_I & wval == 1){
			ival = 1;
		}
		if(e.getKeyCode() == KeyEvent.VK_N & ival == 1){
			nval = 1; 
			if(nval+ival+wval == 3){
				level = 4;
				score = 10000;
			}
		}
		
	}
	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
	
	}
	@Override
	public void keyTyped(KeyEvent e) {
	
	}//decides what level to play
	public void level(){
		if(level == 1){
			if(yval -3 <= bally +34 & bally +34 <= yval + 3 & ballx  >= xval -40 & ballx <= xval+75){
				playcase =1;
				gravity = 0;
				score +=5;
			}
			if(ballx >= 555){
				playcase = 2;
				gravity = 0;
			}
			if(ballx <= 5){
				gravity = 0;
				playcase = 3;
			}
			if(bally <= 5){
				gravity = 0;
				playcase = 4;
			}
			if(bally > 315){
				playcase = 0;
				fallhold +=1;
			}
		}else if(level == 2){
			if(yval -3 <= bally +24 & bally +24 <= yval + 3 & ballx  >= xval -30 & ballx <= xval+65){
				playcase =1;
				gravity = 0;
				score +=5;
			}
			if(ballx >= 565){
				playcase = 2;
				gravity = 0;
			}
			if(ballx <= 5){
				gravity =0;
				playcase = 3;
			}
			if(bally <= 5){
				gravity = 0;
				playcase = 4;
			}
			if(bally > 315){
				playcase = 0;
				fallhold +=1;
			}
		}
		if(level == 3){
			if(yval -3 <= bally +19 & bally +19 <= yval + 3 & ballx  >= xval -25 & ballx <= xval+60){
				gravity = 0;
				playcase =1;
				score +=5;
			}
			if(ballx >= 570){
				gravity = 0;
				playcase = 2;
			}
			if(ballx <= 5){
				gravity = 0;
				playcase = 3;
			}
			if(bally <= 5){
				gravity = 0;
				playcase = 4;
			}
			if(bally > 315){
				playcase = 0;
				fallhold +=1;
			}
		}
	}

}