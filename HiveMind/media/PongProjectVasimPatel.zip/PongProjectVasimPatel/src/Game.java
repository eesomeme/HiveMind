/* Vasim Patel
 * 
 * Project 4 
 * 
 * Lab TR 12:30
 * 
 * TA: George Rossney
 * 
 * I affirm that I have not given or received any unauthorized help on this assignment, and that this work is my own
 */
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Hashtable;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.Timer;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class Game extends JFrame implements ChangeListener, ActionListener {
protected int level = 1;
protected static JLabel Level_Times = new JLabel("Level 1: 30 Level 2: 45 Level 3: 60 "); // length of levels
protected static JButton go = new JButton("Restart");//restart button
protected JSlider goes = new JSlider(0,1);//pull to start the game and pause the game
protected JLabel pause = new JLabel("Press me!"); //starts the game!
Play gameplay = new Play();
	public Game(){
		//sets up the panel and the frame along with the various GUI controls under the panel
		setTitle("Legendary Bouncing Ball On Paddle: Revengencance The Awakening Rising");
		setLayout(null);
		add(gameplay);
		add(Level_Times);
		add(goes);
		add(pause);
		pause.setBounds(72, 312, 100, 10);
		goes.setBounds(50, 333, 100, 24);
		goes.addChangeListener(this);
		goes.setFocusable(false);
		add(go);
		go.setBounds(200,320,100,40);
		go.addActionListener(this);
		go.setFocusable(false);
		Level_Times.setBounds(350, 320, 200, 30);
		gameplay.setFocusable(true);
		gameplay.addKeyListener(gameplay);
		gameplay.setBounds(0, 0, 600, 300);
		gameplay.setBackground(Color.black);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(600, 400);
		setResizable(false);
	

	}
	public static void main(String[] args) {
		new Game().setVisible(true);

	}
	
	@Override
	public void stateChanged(ChangeEvent e) {
		if(goes.getValue() == 1){
			gameplay.setGo(true);
			pause.setText("Play");
		}else{
			gameplay.setGo(false);
			pause.setText("Pause");
		}
		
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		gameplay.setStart(true);
		
	}
}
